import string
import random

def generate_password(length, use_letters, use_numbers, use_symbols):
    """
    Generate a random password based on user-defined criteria
    """
    characters = ""
    if use_letters:
        characters += string.ascii_letters
    if use_numbers:
        characters += string.digits
    if use_symbols:
        characters += string.punctuation

    if not characters:
        print("Error: You must select at least one character type.")
        return None

    password = ''.join(random.choice(characters) for _ in range(length))
    return password

def main():
    print("Password Generator")
    print("----------------")

    # Prompt user for password length
    while True:
        try:
            length = int(input("Enter the password length: "))
            if length < 1:
                print("Password length must be a positive integer. Try again!")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a valid password length.")

    # Prompt user for character set preferences
    use_letters = input("Include letters (y/n)? ").lower() == 'y'
    use_numbers = input("Include numbers (y/n)? ").lower() == 'y'
    use_symbols = input("Include symbols (y/n)? ").lower() == 'y'

    # Generate password
    password = generate_password(length, use_letters, use_numbers, use_symbols)

    if password:
        print(f"Generated password: {password}")

if __name__ == "__main__":
    main()